# include <stdio.h>
# include <windows.h>
# include <stdlib.h> # define MAXSTR 200
# define REBOT "RobotA says: "
# define YOUR "you say: "
# define EXIT "-e\n"
# define NOREPLY "I don't know what you say!\n" 

char * GetRebot(char * str); //return robot reply
void DelHr(char * str); //delete line feed
void RobotSay(char * str); //robot reply

int main(void)
{
	char str[1024];
	printf("**************************chat robot****************************\n");
	printf("\n%sHI,I am chat robot A,very high heart and see you^ ^exit chat,please enter -e\n", REBOT);

	do
	{
		printf("%s", YOUR);
		scanf("%s", str);
		printf("%s", REBOT);

		if (str[0] != '-' && str[1] != 'e')
		{
			RobotSay(GetRebot(str));
			printf("\n");
		}
		else{
			printf("It is really plearsure to chat with you.Welcom to chat with me next time~\n");
		}
	} while (str[0] != '-' && str[1] != 'e');

	return 0;
}

char * GetRebot(char * str)
{
	static char keywords[500];
	char reply[500];
	int i = 0;
	FILE * fp;
	if ((fp = fopen("E:\\reply", "r")) == NULL)
	{
		printf("missing core file!!\n");
		exit(0);
	}
	while (!feof(fp)) //get keyword
	{
		i++;
		fgets(keywords, 500, fp);
		DelHr(keywords);

		if (i % 2 != 0)
		{
			if (strstr(str, keywords) != 0)
			{
				fgets(reply, 500, fp);
				return reply;
			}
		}
	}

	fclose(fp);
	return NOREPLY;
}

void DelHr(char * str)
{
	int i, j;

	for (i = 0; str[i] != '\0'; i++)
	{
		if (str[i] == '\n')
		{
			for (j = i; str[j] != '\0'; j++)
			{
				str[j] = str[j + 1];
			}
		}
	}
}

void RobotSay(char * str)
{
	int i; for (i = 0; str[i] != '\0'; i++)
	{
		Sleep(80);

		printf("%c", str[i]);
	}
}